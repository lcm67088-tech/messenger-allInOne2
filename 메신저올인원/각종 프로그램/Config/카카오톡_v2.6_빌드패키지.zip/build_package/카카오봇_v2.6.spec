# -*- mode: python ; coding: utf-8 -*-
"""
카카오톡 플로팅 자동화 v2.6
PyInstaller .spec 파일

사용법:
    pyinstaller 카카오봇_v2.6.spec
"""

block_cipher = None

a = Analysis(
    ['카카오톡_올인원_v2.6.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[
        'pyautogui',
        'pyscreeze',
        'PIL',
        'PIL._imagingtk',
        'PIL.Image',
        'keyboard',
        'requests',
        'requests.adapters',
        'requests.auth',
        'requests.models',
        'requests.sessions',
        'requests.packages',
        'urllib3',
        'certifi',
        'charset_normalizer',
        'idna',
        'csv',
        'json',
        'tkinter',
        'tkinter.ttk',
        'tkinter.messagebox',
        'tkinter.filedialog',
        'threading',
        'datetime',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'matplotlib',
        'numpy',
        'scipy',
        'pandas',
        'IPython',
        'jupyter',
        'notebook',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='카카오톡_플로팅_자동화_v2.6',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,          # GUI 앱 — 콘솔 창 숨김
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon='icon.ico',      # 아이콘 파일이 있으면 주석 해제
)
