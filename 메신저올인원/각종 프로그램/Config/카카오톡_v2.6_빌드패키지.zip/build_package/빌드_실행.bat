@echo off
chcp 65001 > nul
echo ============================================
echo  카카오톡 플로팅 자동화 v2.6 - EXE 빌드
echo ============================================
echo.

:: Python 설치 확인
python --version >nul 2>&1
if errorlevel 1 (
    echo [오류] Python이 설치되어 있지 않습니다.
    echo  https://www.python.org/downloads/ 에서 설치해주세요.
    pause
    exit /b 1
)

echo [1/3] 필요 패키지 설치 중...
pip install pyinstaller pyautogui keyboard requests Pillow --upgrade --quiet
if errorlevel 1 (
    echo [오류] 패키지 설치 실패
    pause
    exit /b 1
)
echo       완료!
echo.

echo [2/3] EXE 빌드 중... (1~3분 소요)
pyinstaller 카카오봇_v2.6.spec --clean --noconfirm
if errorlevel 1 (
    echo [오류] 빌드 실패. 위 오류 메시지를 확인하세요.
    pause
    exit /b 1
)
echo       완료!
echo.

echo [3/3] 결과물 정리...
if exist "dist\카카오톡_플로팅_자동화_v2.6.exe" (
    copy /Y "dist\카카오톡_플로팅_자동화_v2.6.exe" "카카오톡_플로팅_자동화_v2.6.exe" >nul
    echo.
    echo ============================================
    echo  빌드 성공!
    echo  파일: 카카오톡_플로팅_자동화_v2.6.exe
    echo ============================================
    echo.
    echo  [배포 시 주의]
    echo  EXE 실행 후 자동으로 Config\ 폴더가 생성됩니다.
    echo  EXE 파일과 Config\ 폴더를 함께 배포하세요.
    echo.
) else (
    echo [오류] EXE 파일을 찾을 수 없습니다. dist\ 폴더를 확인하세요.
)

pause
