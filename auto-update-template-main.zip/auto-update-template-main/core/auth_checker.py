#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
auth_checker.py  ─  구글 스프레드시트 기반 인증 모듈
────────────────────────────────────────────────────────────
Google Sheets CSV export URL에서 허용 계정 목록을 실시간으로 불러와
ID / PW / EXPIRE / STATUS 를 검증함.

스프레드시트 컬럼 구조:
    ID | PW | EXPIRE (YYYY-MM-DD) | STATUS (ACTIVE/INACTIVE)

개발자 관리 방법:
    - 구글 시트에서 직접 계정 추가/삭제
    - STATUS = INACTIVE 로 바꾸면 즉시 차단
    - EXPIRE 날짜 지나면 자동 차단
    - EXE 재배포 불필요
"""

import urllib.request
import urllib.error
import csv
import io
import hashlib
from datetime import date, datetime
from dataclasses import dataclass
from enum import Enum

# ══════════════════════════════════════════════════════════
# 구글 스프레드시트 설정
# ══════════════════════════════════════════════════════════
SHEET_ID  = "YOUR_GOOGLE_SHEET_ID"
GID       = "0"  # 시트 탭 GID (URL ?gid=숫자)
CSV_URL   = (
    f"https://docs.google.com/spreadsheets/d/{SHEET_ID}"
    f"/export?format=csv&gid={GID}"
)
TIMEOUT   = 8   # 네트워크 타임아웃(초)


# ══════════════════════════════════════════════════════════
# 인증 결과 타입
# ══════════════════════════════════════════════════════════
class AuthResult(Enum):
    OK            = "ok"
    WRONG_ID_PW   = "wrong_id_pw"      # ID 또는 PW 불일치
    EXPIRED       = "expired"           # 유효기간 만료
    INACTIVE      = "inactive"          # STATUS = INACTIVE
    OFFLINE       = "offline"           # 네트워크 연결 불가
    SHEET_ERROR   = "sheet_error"       # 시트 파싱 오류


@dataclass
class AuthInfo:
    result:   AuthResult
    message:  str = ""
    user_id:  str = ""
    expire:   str = ""          # 만료일 (표시용)


# ══════════════════════════════════════════════════════════
# 스프레드시트 로드
# ══════════════════════════════════════════════════════════
def _fetch_sheet_csv(timeout: int = TIMEOUT) -> str | None:
    """구글 시트 CSV 텍스트 반환. 실패 시 None"""
    try:
        req = urllib.request.Request(
            CSV_URL,
            headers={"User-Agent": "TelegramParser-Auth/1.4"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8")
    except Exception:
        return None


def _parse_accounts(csv_text: str) -> list[dict]:
    """
    CSV → 계정 딕셔너리 리스트 변환
    반환: [{"id": ..., "pw": ..., "expire": ..., "status": ...}, ...]
    """
    accounts = []
    reader = csv.DictReader(io.StringIO(csv_text))
    for row in reader:
        # 컬럼명 대소문자 무관하게 처리
        normalized = {k.strip().upper(): v.strip() for k, v in row.items()}
        acc = {
            "id":     normalized.get("ID", ""),
            "pw":     normalized.get("PW", ""),
            "expire": normalized.get("EXPIRE", ""),
            "status": normalized.get("STATUS", "").upper(),
        }
        if acc["id"]:   # ID 없는 빈 행 제외
            accounts.append(acc)
    return accounts


# ══════════════════════════════════════════════════════════
# 인증 로직
# ══════════════════════════════════════════════════════════
def _check_expire(expire_str: str) -> bool:
    """
    만료일 검사.
    EXPIRE 컬럼이 비어있으면 무기한 허용.
    반환: True = 아직 유효, False = 만료됨
    """
    if not expire_str:
        return True
    try:
        expire_date = datetime.strptime(expire_str, "%Y-%m-%d").date()
        return date.today() <= expire_date
    except ValueError:
        return True   # 날짜 형식 오류 → 허용 (관대하게 처리)


def verify(user_id: str, password: str) -> AuthInfo:
    """
    메인 인증 함수.
    입력: 사용자가 입력한 ID / PW
    반환: AuthInfo 객체
    """
    user_id  = user_id.strip()
    password = password.strip()

    # ── 시트 로드 ────────────────────────────────────
    csv_text = _fetch_sheet_csv()
    if csv_text is None:
        return AuthInfo(
            result  = AuthResult.OFFLINE,
            message = "서버에 연결할 수 없습니다.\n인터넷 연결을 확인하세요.",
        )

    # ── 파싱 ─────────────────────────────────────────
    try:
        accounts = _parse_accounts(csv_text)
    except Exception as e:
        return AuthInfo(
            result  = AuthResult.SHEET_ERROR,
            message = f"인증 데이터 오류: {e}",
        )

    if not accounts:
        return AuthInfo(
            result  = AuthResult.SHEET_ERROR,
            message = "허용 계정 목록이 비어 있습니다.",
        )

    # ── ID 검색 ───────────────────────────────────────
    matched = None
    for acc in accounts:
        if acc["id"].lower() == user_id.lower():
            matched = acc
            break

    if matched is None:
        return AuthInfo(
            result  = AuthResult.WRONG_ID_PW,
            message = "아이디 또는 비밀번호가 올바르지 않습니다.",
        )

    # ── PW 검사 (대소문자 구분) ───────────────────────
    if matched["pw"] != password:
        return AuthInfo(
            result  = AuthResult.WRONG_ID_PW,
            message = "아이디 또는 비밀번호가 올바르지 않습니다.",
        )

    # ── STATUS 검사 ───────────────────────────────────
    if matched["status"] not in ("ACTIVE", ""):
        return AuthInfo(
            result  = AuthResult.INACTIVE,
            message = f"계정이 비활성화되었습니다. (STATUS={matched['status']})\n관리자에게 문의하세요.",
            user_id = matched["id"],
        )

    # ── 만료일 검사 ───────────────────────────────────
    if not _check_expire(matched["expire"]):
        return AuthInfo(
            result  = AuthResult.EXPIRED,
            message = f"사용 기간이 만료되었습니다. (만료일: {matched['expire']})\n관리자에게 문의하세요.",
            user_id = matched["id"],
            expire  = matched["expire"],
        )

    # ── 인증 성공 ─────────────────────────────────────
    return AuthInfo(
        result  = AuthResult.OK,
        message = f"로그인 성공",
        user_id = matched["id"],
        expire  = matched["expire"],
    )
