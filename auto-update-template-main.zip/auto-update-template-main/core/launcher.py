#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
launcher.py  v1.5.0  ─  Telegram Parser EXE 진입점
════════════════════════════════════════════════════════════════
실행 순서:
  1. 로그인 창  (Google Sheets 화이트리스트 인증)
     └─ 인증 실패 / 취소 → 즉시 종료
  2. 스플래시 창 표시
  3. 백그라운드: GitHub Private 레포 버전 체크
  4. 새 버전 발견 → 업데이트 확인 팝업
     ├─ [지금 업데이트] → .enc 다운로드 → 앱 실행
     └─ [나중에] / force_update=True 처리
  5. 스플래시 닫기 → telegram_parser.enc 복호화 → 메모리 실행

4단계 보안 레이어:
  [1] Google Sheets 로그인  (ID / PW / 만료일 / 상태)
  [2] Private GitHub 레포   (PAT XOR+Base64 난독화)
  [3] AES-256-CBC 암호화    (.enc 파일, 디스크에 평문 없음)
  [4] 메모리 실행           (복호화 후 exec(), 파일로 안 씀)

변경 이력:
  v1.5.0 (2026-04-26) — 전면 개편
    · force_update 지원 (사용자 거부 불가 강제 업데이트)
    · 업데이트 다이얼로그 SHA-256 해시 표시 추가
    · 오류 로그 timestamp 추가
    · _load_and_run_encrypted 오류 메시지 상세화
    · 스플래시 UI 버전 표기 개선
  v1.4.3 (2026-04-26) — _injected_auto_updater import 수정
  v1.4.0 (2026-04-26) — Google Sheets 로그인 + AES 실행 추가
════════════════════════════════════════════════════════════════
"""

import sys
import os
import threading
import traceback
import types
import time
import datetime
import tkinter as tk
import tkinter.messagebox as messagebox
from pathlib import Path

# ── auto_updater 임포트 ──────────────────────────────────────
# ⚠ build.bat → inject_token.py 가 이 줄을 아래처럼 교체:
#   from _injected_auto_updater import ...
# 그래야 PAT/AES 키가 주입된 버전이 EXE 에 번들링됨
try:
    from auto_updater import (
        check_update,
        apply_update,
        decrypt_file,
        _decode_aes_key,
        LOCAL_ENC,
        APP_DIR,
    )
    UPDATER_OK  = True
    UPDATER_ERR = ""
except ImportError as e:
    UPDATER_OK  = False
    UPDATER_ERR = str(e)

# ── 로그인 모듈 임포트 ──────────────────────────────────────
try:
    from login_window import LoginWindow
    LOGIN_OK  = True
    LOGIN_ERR = ""
except ImportError as e:
    LOGIN_OK  = False
    LOGIN_ERR = str(e)


LAUNCHER_VERSION = "1.0.0"
APP_TITLE        = "YOUR_APP_NAME"

# ── 색상 팔레트 ──────────────────────────────────────────────
C = {
    "bg":       "#1a1a2e",
    "card":     "#0f3460",
    "accent":   "#e94560",
    "accent2":  "#533483",
    "green":    "#4ecca3",
    "yellow":   "#f5a623",
    "text":     "#eaeaea",
    "sub":      "#a8a8b3",
    "border":   "#2a2a4a",
    "btn_ok":   "#e94560",
    "btn_skip": "#0f3460",
}


# ════════════════════════════════════════════════════════════════
# 암호화된 .enc → 메모리 실행
# ════════════════════════════════════════════════════════════════
def _load_and_run_encrypted():
    """
    telegram_parser.enc 를 복호화하여 메모리에서 직접 실행.
    소스코드는 디스크에 평문으로 쓰이지 않음 (보안 레이어 ④).
    """
    # 1) EXE 옆의 .enc 우선 (업데이트된 버전)
    ext_enc = LOCAL_ENC if UPDATER_OK else _fallback_enc_path()

    # 2) PyInstaller 내장 .enc (MEIPASS)
    meipass_enc = None
    if getattr(sys, "frozen", False):
        meipass = Path(getattr(sys, "_MEIPASS", ""))
        candidate = meipass / "telegram_parser.enc"
        if candidate.exists():
            meipass_enc = candidate

    # 어느 경로 사용할지 결정 (외부 우선)
    if ext_enc.exists():
        enc_file = ext_enc
    elif meipass_enc and meipass_enc.exists():
        enc_file = meipass_enc
    else:
        raise FileNotFoundError(
            f"telegram_parser.enc 를 찾을 수 없습니다.\n\n"
            f"확인 경로:\n  (1) {ext_enc}\n  (2) {meipass_enc or '없음'}\n\n"
            "build.bat 으로 다시 빌드하거나, GitHub 에서 파일을 받으세요."
        )

    # 복호화 (보안 레이어 ③+④)
    raw_enc = enc_file.read_bytes()
    source  = decrypt_file(raw_enc)       # → Python 소스코드 bytes

    # 메모리 실행
    src_str = source.decode("utf-8")
    code    = compile(src_str, "<telegram_parser>", "exec")
    mod     = types.ModuleType("telegram_parser")
    mod.__file__ = str(enc_file)
    sys.modules["telegram_parser"] = mod
    exec(code, mod.__dict__)

    # main() 또는 TelegramParserApp 호출
    if hasattr(mod, "main"):
        mod.main()
    elif hasattr(mod, "TelegramParserApp"):
        app = mod.TelegramParserApp()
        app.mainloop()
    else:
        raise AttributeError(
            "telegram_parser.py 에 main() 함수 또는 "
            "TelegramParserApp 클래스가 없습니다."
        )


def _fallback_enc_path() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent / "telegram_parser.enc"
    return Path(__file__).parent / "telegram_parser.enc"


# ════════════════════════════════════════════════════════════════
# 스플래시 창
# ════════════════════════════════════════════════════════════════
class SplashWindow(tk.Tk):

    def __init__(self):
        super().__init__()
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(bg=C["bg"])

        W, H = 500, 280
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")

        # 테두리 효과
        border = tk.Frame(self, bg=C["accent"], padx=2, pady=2)
        border.pack(fill="both", expand=True)
        inner = tk.Frame(border, bg=C["bg"])
        inner.pack(fill="both", expand=True)

        # 아이콘 + 타이틀
        tk.Label(inner, text="✈",
            font=("Segoe UI Emoji", 34),
            bg=C["bg"], fg=C["accent"],
        ).pack(pady=(22, 0))

        tk.Label(inner, text=APP_TITLE,
            font=("Malgun Gothic", 15, "bold"),
            bg=C["bg"], fg=C["text"],
        ).pack(pady=(4, 2))

        tk.Label(inner,
            text=f"v{LAUNCHER_VERSION}  ·  YOUR_GITHUB_USERNAME / YOUR_REPO_NAME",
            font=("Malgun Gothic", 8),
            bg=C["bg"], fg=C["sub"],
        ).pack()

        tk.Frame(inner, bg=C["border"], height=1).pack(fill="x", padx=30, pady=(14, 10))

        # 상태 레이블
        self._status_var = tk.StringVar(value="업데이트 확인 중...")
        self._status_lbl = tk.Label(inner,
            textvariable=self._status_var,
            font=("Malgun Gothic", 10),
            bg=C["bg"], fg=C["yellow"],
        )
        self._status_lbl.pack()

        # 프로그레스바 (Canvas)
        self._canvas = tk.Canvas(inner, width=400, height=6,
            bg=C["card"], highlightthickness=0)
        self._canvas.pack(pady=(10, 6))
        self._bar  = self._canvas.create_rectangle(0, 0, 0, 6, fill=C["green"], outline="")
        self._bar_w = 400
        self._anim_x    = 0
        self._animating = True
        self._do_animate()

    # ── 애니메이션 (이동하는 박스) ─────────────────────────
    def _do_animate(self):
        if not self._animating:
            return
        w  = 90
        x1 = self._anim_x % (self._bar_w + w) - w
        self._canvas.coords(self._bar, x1, 0, x1 + w, 6)
        self._anim_x += 7
        self.after(15, self._do_animate)

    # ── 외부 호출 메서드 ────────────────────────────────────
    def set_status(self, msg: str, color: str | None = None):
        self._status_var.set(msg)
        if color:
            self._status_lbl.config(fg=color)
        self.update_idletasks()

    def set_progress(self, pct: float):
        """0.0 ~ 1.0"""
        self._animating = False
        w = int(self._bar_w * max(0.0, min(pct, 1.0)))
        self._canvas.coords(self._bar, 0, 0, w, 6)
        self.update_idletasks()

    def done(self):
        self._animating = False
        self._canvas.coords(self._bar, 0, 0, self._bar_w, 6)
        self.update_idletasks()


# ════════════════════════════════════════════════════════════════
# 업데이트 다이얼로그
# ════════════════════════════════════════════════════════════════
def show_update_dialog(parent: tk.Misc, info) -> bool:
    """
    업데이트 팝업을 표시하고 사용자 선택을 반환합니다.
    info.force_update=True 이면 [나중에] 버튼을 비활성화합니다.
    반환: True = 지금 업데이트, False = 나중에
    """
    dlg = tk.Toplevel(parent)
    dlg.title("새 버전 발견")
    dlg.configure(bg=C["bg"])
    dlg.resizable(False, False)
    dlg.attributes("-topmost", True)
    dlg.grab_set()

    W, H = 460, 310
    sw = dlg.winfo_screenwidth()
    sh = dlg.winfo_screenheight()
    dlg.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")

    tk.Label(dlg, text="🆕  새 버전이 있습니다!",
        font=("Malgun Gothic", 13, "bold"),
        bg=C["bg"], fg=C["green"],
    ).pack(pady=(20, 4))

    tk.Label(dlg,
        text=f"현재: v{info.local_ver}   →   최신: v{info.remote_ver}",
        font=("Malgun Gothic", 10),
        bg=C["bg"], fg=C["text"],
    ).pack(pady=2)

    meta_parts = []
    if info.release_date:
        meta_parts.append(f"릴리즈: {info.release_date}")
    if info.force_update:
        meta_parts.append("⚠ 필수 업데이트")
    if meta_parts:
        tk.Label(dlg, text="  |  ".join(meta_parts),
            font=("Malgun Gothic", 9),
            bg=C["bg"], fg=C["yellow"] if info.force_update else C["sub"],
        ).pack()

    tk.Frame(dlg, bg=C["border"], height=1).pack(fill="x", padx=30, pady=8)

    note_frm = tk.Frame(dlg, bg=C["card"], padx=12, pady=8)
    note_frm.pack(fill="x", padx=30)
    tk.Label(note_frm,
        text=info.update_note or "(업데이트 내용 없음)",
        font=("Malgun Gothic", 9),
        bg=C["card"], fg=C["text"],
        wraplength=380, justify="left",
    ).pack(anchor="w")

    # SHA-256 표시 (있을 때만)
    if info.enc_sha256:
        tk.Label(dlg,
            text=f"SHA-256: {info.enc_sha256[:16]}...",
            font=("Courier New", 8),
            bg=C["bg"], fg=C["sub"],
        ).pack(pady=(4, 0))

    notice = "※ 필수 업데이트입니다. 지금 업데이트해야 합니다." if info.force_update \
             else "※ 업데이트는 다음 실행 시 자동 적용됩니다."
    tk.Label(dlg, text=notice,
        font=("Malgun Gothic", 8),
        bg=C["bg"], fg=C["accent"] if info.force_update else C["sub"],
    ).pack(pady=(6, 4))

    result = {"val": False}

    def on_update():
        result["val"] = True
        dlg.destroy()

    def on_skip():
        result["val"] = False
        dlg.destroy()

    btn_frame = tk.Frame(dlg, bg=C["bg"])
    btn_frame.pack(pady=4)

    tk.Button(btn_frame, text="✅  지금 업데이트",
        command=on_update,
        bg=C["btn_ok"], fg="#fff",
        font=("Malgun Gothic", 10, "bold"),
        relief="flat", cursor="hand2",
        width=16, pady=8,
        activebackground="#c73652",
    ).pack(side="left", padx=(0, 10))

    skip_btn = tk.Button(btn_frame, text="⏭  나중에",
        command=on_skip,
        bg=C["btn_skip"], fg=C["sub"],
        font=("Malgun Gothic", 10),
        relief="flat", cursor="hand2",
        width=10, pady=8,
    )
    skip_btn.pack(side="left")

    if info.force_update:
        skip_btn.config(state="disabled", fg="#555555")

    dlg.wait_window()
    return result["val"]


# ════════════════════════════════════════════════════════════════
# 런처 메인 흐름
# ════════════════════════════════════════════════════════════════
def main():
    # ══════════════════════════════════════════
    # STEP 1: Google Sheets 로그인 인증
    # ══════════════════════════════════════════
    if not LOGIN_OK:
        # 로그인 모듈 누락 → 개발자 모드 확인
        _root = tk.Tk()
        _root.withdraw()
        proceed = messagebox.askyesno(
            "경고 — 로그인 모듈 없음",
            f"login_window 모듈을 불러올 수 없습니다:\n{LOGIN_ERR}\n\n"
            "인증 없이 계속하시겠습니까?\n(⚠ 개발자 모드 전용)",
        )
        _root.destroy()
        if not proceed:
            sys.exit(0)
    else:
        login_win     = LoginWindow()
        authenticated = login_win.run()
        if not authenticated:
            sys.exit(0)

    # ══════════════════════════════════════════
    # STEP 2: 스플래시 창 표시
    # ══════════════════════════════════════════
    splash = SplashWindow()
    splash.update()

    # 업데이터 없으면 즉시 실행
    if not UPDATER_OK:
        splash.set_status(
            f"업데이터 없음 ({UPDATER_ERR[:40]}...) — 바로 실행합니다.",
            C["yellow"],
        )
        splash.done()
        splash.after(900, lambda: _close_and_run(splash))
        splash.mainloop()
        return

    # ══════════════════════════════════════════
    # STEP 3: 백그라운드 버전 체크
    # ══════════════════════════════════════════
    state = {"info": None, "done": False}

    def do_check():
        state["info"] = check_update()
        state["done"] = True

    threading.Thread(target=do_check, daemon=True).start()

    def poll_check():
        if not state["done"]:
            splash.after(100, poll_check)
            return
        on_check_done(state["info"])

    def on_check_done(info):
        # ── 오프라인 ──────────────────────────
        if not info.online:
            splash.set_status(
                f"오프라인 — v{info.local_ver} 실행 중...",
                C["yellow"],
            )
            splash.done()
            splash.after(900, lambda: _close_and_run(splash))
            return

        # ── 최신 버전 ─────────────────────────
        if not info.available:
            splash.set_status(
                f"최신 버전  v{info.local_ver}  ✓",
                C["green"],
            )
            splash.done()
            splash.after(700, lambda: _close_and_run(splash))
            return

        # ── 새 버전 발견 ───────────────────────
        splash.set_status(
            f"새 버전 발견  v{info.local_ver} → v{info.remote_ver}",
            C["accent"],
        )
        splash.done()
        splash.update()

        # ══════════════════════════════════════
        # STEP 4: 업데이트 팝업
        # ══════════════════════════════════════
        want = show_update_dialog(splash, info)

        if not want and not info.force_update:
            # 사용자 거부 (강제 업데이트 아닌 경우)
            splash.after(200, lambda: _close_and_run(splash))
            return

        # ── 다운로드 ──────────────────────────
        splash.set_status("다운로드 중...", C["yellow"])
        splash._animating = True
        splash._do_animate()

        def do_download():
            def progress(dl, total):
                pct = dl / total if total else 0
                splash.after(0, lambda: splash.set_progress(pct))
            ok, msg = apply_update(progress_cb=progress)
            splash.after(0, lambda: on_download_done(ok, msg))

        def on_download_done(ok, msg):
            if ok:
                splash.set_status("✅ 업데이트 완료!  앱 시작 중...", C["green"])
                splash.done()
                splash.after(800, lambda: _close_and_run(splash))
            else:
                splash.set_status("❌ 업데이트 실패 — 현재 버전으로 실행", C["accent"])
                splash.done()
                messagebox.showwarning("업데이트 실패",
                    f"{msg}\n\n현재 버전으로 계속 실행합니다.")
                splash.after(400, lambda: _close_and_run(splash))

        threading.Thread(target=do_download, daemon=True).start()

    splash.after(200, poll_check)
    splash.mainloop()


# ════════════════════════════════════════════════════════════════
# 스플래시 닫기 & 메인 앱 실행
# ════════════════════════════════════════════════════════════════
def _close_and_run(splash: tk.Tk):
    """스플래시를 닫고 암호화된 메인 앱을 복호화하여 실행합니다."""
    try:
        splash.destroy()
    except Exception:
        pass

    try:
        _load_and_run_encrypted()
    except Exception:
        err = traceback.format_exc()
        try:
            _root = tk.Tk()
            _root.withdraw()
            messagebox.showerror("실행 오류",
                f"메인 앱 실행 실패:\n\n{err}\n\n"
                "error.log 파일을 확인하거나 개발자에게 문의하세요.")
            _root.destroy()
        except Exception:
            pass
        _write_error_log(err)
        sys.exit(1)


# ════════════════════════════════════════════════════════════════
# 오류 로그 기록
# ════════════════════════════════════════════════════════════════
def _write_error_log(text: str):
    try:
        if getattr(sys, "frozen", False):
            log_path = Path(sys.executable).parent / "error.log"
        else:
            log_path = Path(__file__).parent / "error.log"
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"\n{'='*60}\n[{timestamp}]\n{text}\n")
    except Exception:
        pass


# ════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        try:
            _root = tk.Tk()
            _root.withdraw()
            messagebox.showerror("치명적 오류", f"프로그램 시작 실패:\n\n{err}")
            _root.destroy()
        except Exception:
            pass
        _write_error_log(err)
        sys.exit(1)
