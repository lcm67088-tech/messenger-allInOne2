#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
myapp_template.py  ─  메인 앱 템플릿
════════════════════════════════════════════════════════════════
이 파일을 복사해서 실제 앱을 만드세요.
파일명을 바꿀 때 build.bat 의 --name 옵션도 함께 바꾸세요.

필수 조건:
  - main() 함수가 반드시 모듈 레벨에 존재해야 합니다.
  - if __name__ == "__main__": 안에만 있으면 launcher 에서 호출 불가!
════════════════════════════════════════════════════════════════
"""

import tkinter as tk
import tkinter.messagebox as messagebox


class MyApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("내 앱")                     # ← 앱 이름 수정
        self.geometry("800x600")
        self.configure(bg="#1a1a2e")
        self._build_ui()

    def _build_ui(self):
        tk.Label(
            self,
            text="✅ 앱이 정상 실행되었습니다!",
            font=("Malgun Gothic", 20, "bold"),
            bg="#1a1a2e", fg="#4ecca3",
        ).pack(expand=True)

        tk.Label(
            self,
            text="이 부분을 실제 앱 UI로 교체하세요.",
            font=("Malgun Gothic", 11),
            bg="#1a1a2e", fg="#a8a8b3",
        ).pack()


# ════════════════════════════════════════════════════════════════
# ⚠ 이 함수는 반드시 모듈 레벨(if __name__ 바깥)에 있어야 합니다.
#   launcher.py 가 AES 복호화 후 exec() 로 실행하고
#   mod.main() 을 직접 호출하기 때문입니다.
# ════════════════════════════════════════════════════════════════
def main():
    app = MyApp()
    app.mainloop()


if __name__ == "__main__":
    main()
