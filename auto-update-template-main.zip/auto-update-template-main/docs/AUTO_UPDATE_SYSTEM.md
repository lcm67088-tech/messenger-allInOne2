# 🔄 Python EXE 자동 업데이트 + 보안 시스템 — 완전 설계 문서

> **기준 레포**: `lcm67088-tech/program222` (브랜치: `telegram-parser`)  
> **현재 버전**: v1.5.0 (2026-04-26)  
> **이 문서는 동일한 구조를 다른 프로그램에 그대로 적용할 수 있도록 작성되었습니다.**

---

## 📌 핵심 개념

> **"EXE 안에 AES-256 으로 암호화된 메인 앱(.enc)을 내장하고,  
> GitHub Private 브랜치에서 최신 .enc 를 받아 다음 실행 때 자동 반영.  
> 실행 전 Google Sheets 로그인으로 허가된 사용자만 접근 가능."**

---

## 1. 전체 아키텍처

```
┌──────────────────────────────────────────────────────────────────┐
│                          사용자 PC                                │
│                                                                  │
│  telegram_parser.exe                                             │
│  ├── [내장] _injected_launcher.py     ← EXE 진입점              │
│  │         (PAT/AES 주입 버전)                                   │
│  ├── [내장] _injected_auto_updater.py ← GitHub API 버전체크      │
│  │         (PAT/AES 주입 버전)                                   │
│  ├── [내장] auth_checker.py           ← Google Sheets 인증       │
│  ├── [내장] login_window.py           ← 로그인 GUI               │
│  └── [내장] telegram_parser.enc       ← AES-256 암호화된 메인앱  │
│                                                                  │
│  EXE 옆에 생기는 파일들 (런타임)                                   │
│  ├── telegram_parser.enc   ← 업데이트 시 GitHub에서 교체          │
│  ├── telegram_parser.enc.bak ← 이전 버전 자동 백업               │
│  └── local_version.json   ← 현재 설치 버전 정보                  │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
              ↕ HTTPS (GitHub API - Bearer 인증)
┌──────────────────────────────────────────────────────────────────┐
│  GitHub: lcm67088-tech/program222  (브랜치: telegram-parser)     │
│  ├── version.json          ← 최신 버전 정보 + SHA-256            │
│  └── telegram_parser.enc   ← AES-256 암호화된 최신 소스코드      │
└──────────────────────────────────────────────────────────────────┘
              ↕ HTTPS (Google Sheets CSV Export)
┌──────────────────────────────────────────────────────────────────┐
│  Google Sheets (공개 CSV)                                        │
│  ID | PW | EXPIRE (YYYY-MM-DD) | STATUS (ACTIVE/INACTIVE)       │
└──────────────────────────────────────────────────────────────────┘
```

---

## 2. 4단계 보안 레이어

| 레이어 | 구성요소 | 보호 대상 | 우회 불가 이유 |
|--------|---------|----------|-------------|
| **[1] 로그인** | `login_window.py` + `auth_checker.py` | 무단 사용자 접근 | Google Sheets 실시간 조회, 5회 실패 시 강제 종료 |
| **[2] Private 레포** | `auto_updater.py` (_PAT XOR+Base64 난독화_) | 소스코드 노출 | PAT 없이 API 접근 불가, 토큰은 EXE 내부에만 존재 |
| **[3] AES-256 암호화** | `inject_token.py` → `.enc` 파일 | 소스코드 역공학 | AES-256-CBC, 키는 EXE 내부에만, 디스크에 평문 없음 |
| **[4] 메모리 실행** | `launcher.py` → `exec()` | 런타임 소스 추출 | 복호화된 코드가 파일로 쓰이지 않음, RAM 에만 존재 |

---

## 3. 파일 구성

### 개발 머신 (GitHub 레포)

| 파일 | 역할 | GitHub 커밋? | EXE 내장? |
|------|------|------------|----------|
| `launcher.py` | EXE 진입점 (로그인→스플래시→업데이트→실행) | ✅ | ❌ (주입 후 `_injected_launcher.py` 사용) |
| `auto_updater.py` | GitHub API 버전체크 / .enc 다운로드 | ✅ | ❌ (주입 후 `_injected_auto_updater.py` 사용) |
| `auth_checker.py` | Google Sheets CSV 인증 로직 | ✅ | ✅ |
| `login_window.py` | 로그인 GUI (Tkinter) | ✅ | ✅ |
| `telegram_parser.py` | 메인 앱 소스 (원본) | ✅ | ❌ |
| `telegram_parser.enc` | AES-256 암호화된 메인 앱 | ✅ | ✅ |
| `version.json` | 버전 정보 + SHA-256 | ✅ | ✅ |
| `build.bat` | PyInstaller 빌드 스크립트 | ✅ | ❌ |
| `inject_token.py` | 빌드 전 PAT/AES 주입 도구 | ✅ | ❌ |
| `make_icon.py` | 아이콘 생성 스크립트 | ✅ | ❌ |
| `.aes_key` | AES 키 (32 bytes 바이너리) | **❌ 절대 금지** | EXE 내부에 Base64 포함 |
| `.pat` | GitHub PAT 토큰 | **❌ 절대 금지** | EXE 내부에 XOR 포함 |
| `_injected_*.py` | 빌드 중간 생성물 | **❌** | - |

### 사용자 PC (배포)

| 파일 | 생성 시점 | 설명 |
|------|---------|------|
| `telegram_parser.exe` | 빌드 | 배포 파일 (단일 EXE) |
| `telegram_parser.enc` | 업데이트 다운로드 시 | 최신 소스 (암호화) |
| `telegram_parser.enc.bak` | 업데이트 전 자동 백업 | 롤백용 |
| `local_version.json` | 업데이트 후 | 현재 설치 버전 기록 |
| `error.log` | 오류 발생 시 | 타임스탬프 포함 오류 로그 |

---

## 4. 실행 흐름 (상세)

```
사용자가 telegram_parser.exe 더블클릭
          │
          ▼
[레이어 1]  login_window.py 실행
          │  Google Sheets CSV 로드 (실시간)
          │  ID / PW 입력 → auth_checker.verify()
          │    ├─ STATUS ≠ ACTIVE   → 거부
          │    ├─ EXPIRE 날짜 초과  → 거부
          │    ├─ ID/PW 불일치      → 남은 시도 횟수 표시
          │    └─ 5회 실패          → 강제 종료
          │
          ▼ (인증 성공)
[레이어 2]  SplashWindow 표시
          │
          ▼
          백그라운드 스레드: check_update() 실행
          │  _decode_token() → XOR+Base64 복원 → PAT 획득
          │  GitHub API: GET /repos/.../contents/version.json?ref=telegram-parser
          │  (Authorization: Bearer <PAT>)
          │
          ├─ 오프라인 / 인증 오류 → "오프라인 — 현재 버전 실행"
          │
          ├─ 최신 버전 → "최신 버전 vX.Y.Z ✓"
          │
          └─ 새 버전 발견
               │
               ▼
          show_update_dialog()
          "v1.4.x → v1.5.0 업데이트하시겠습니까?"
          (force_update=true 이면 [나중에] 버튼 비활성화)
               │
               ├─ [나중에] → 현재 버전으로 진행
               │
               └─ [지금 업데이트]
                    │
                    ▼
               apply_update()
               GitHub API: GET .../telegram_parser.enc
               → .tmp 저장 → SHA-256 검증 → .bak 백업 → 파일 교체
               local_version.json 갱신
                    │
                    ├─ 성공 → "업데이트 완료"
                    └─ 실패 → .bak 복구 → 경고 → 현재 버전 실행

          ▼
[레이어 3+4]  _load_and_run_encrypted()
          │  1. EXE 옆 telegram_parser.enc 로드 (없으면 내장 버전)
          │  2. _decode_aes_key() → AES 키 획득 (EXE 내부)
          │  3. AES-256-CBC 복호화 → Python 소스코드 bytes
          │  4. compile() → exec() → 메모리 실행 (파일로 안 씀)
          │  5. mod.main() 호출
          ▼
          메인 앱 실행
```

---

## 5. 빌드 흐름 (build.bat)

```
build.bat 실행
    │
    ├─ [1/8] Python 탐색 (3.11 우선, 3.14까지 지원)
    │         절대 경로 확보 (py launcher temp file 방식)
    │
    ├─ [2/8] 의존성 확인 / 설치
    │         pyinstaller, telethon, Pillow, pycryptodome
    │
    ├─ [3/8] icon.ico 없으면 make_icon.py 로 생성
    │
    ├─ [4/8] PAT 토큰 로드
    │         우선순위: 환경변수 GITHUB_PAT → .pat 파일 → 직접 입력
    │
    ├─ inject_token.py 실행
    │    ├─ PAT XOR+Base64 난독화
    │    ├─ AES 키 생성/로드 (.aes_key)
    │    ├─ telegram_parser.py → AES-256-CBC 암호화 → .enc
    │    ├─ SHA-256 계산 → version.json enc_sha256 업데이트
    │    ├─ auto_updater.py → _injected_auto_updater.py (토큰+키 삽입)
    │    └─ launcher.py → _injected_launcher.py (import 경로 교체)
    │
    ├─ [5/8] 실행 중인 EXE 종료 (taskkill) + dist/build 폴더 삭제
    │
    ├─ [6/8] PyInstaller 빌드
    │         --onefile --noconsole
    │         진입점: _injected_launcher.py
    │         내장: _injected_auto_updater.py (hidden-import)
    │         내장: auth_checker.py, login_window.py
    │         내장: telegram_parser.enc, version.json
    │
    ├─ [7/8] EXE 이름 정리 (_injected_launcher.exe → telegram_parser.exe)
    │
    └─ [8/8] 임시 파일 삭제 (_injected_*.py)
```

---

## 6. version.json 구조

```json
{
  "version": "1.5.0",
  "release_date": "2026-04-26",
  "update_note": "v1.5.0: retry 로직, SHA-256 검증, force_update 지원",
  "main_script": "telegram_parser.enc",
  "encrypted": true,
  "force_update": false,
  "enc_sha256": "abc123def456..."
}
```

| 필드 | 타입 | 설명 | 필수 |
|------|------|------|------|
| `version` | string | SemVer (MAJOR.MINOR.PATCH) | ✅ |
| `release_date` | string | YYYY-MM-DD | 선택 |
| `update_note` | string | 업데이트 팝업 표시 내용 | 선택 |
| `main_script` | string | 다운로드할 파일명 | 선택 |
| `encrypted` | bool | 암호화 여부 | 선택 |
| `force_update` | bool | true = [나중에] 버튼 비활성화 | 선택 |
| `enc_sha256` | string | .enc 파일 SHA-256 hex (무결성 검증) | 선택 |

---

## 7. 버전 관리 규칙 (SemVer)

```
MAJOR . MINOR . PATCH
  │       │       │
  │       │       └── 버그픽스, 소소한 수정
  │       └────────── 새 기능 추가 (하위 호환 유지)
  └────────────────── 전면 개편, 하위 호환 불가
```

| 상황 | 변경 예 |
|------|--------|
| 버그 1개 수정 | 1.4.4 → 1.4.5 |
| 기능 추가 | 1.4.5 → 1.5.0 |
| UI 전면 개편 | 1.5.0 → 2.0.0 |
| 강제 업데이트 (보안 패치) | `"force_update": true` 설정 |

> **규칙: 코드 한 글자라도 바뀌면 반드시 버전을 올릴 것**

---

## 8. 개발자 업데이트 배포 방법

### EXE 재배포 없이 소스만 업데이트

```bash
# 1. telegram_parser.py 수정

# 2. version.json 버전 올리기
{
  "version": "1.5.1",          # ← 버전 증가
  "update_note": "버그 수정: 특정 채팅방 파싱 오류"
}

# 3. build.bat 실행 (inject_token.py 가 자동으로 .enc 재생성 + SHA-256 갱신)
build.bat

# 4. 커밋 & 푸시
git add telegram_parser.enc version.json
git commit -m "release(1.5.1): 특정 채팅방 파싱 오류 수정"
git push origin telegram-parser

# 끝. 사용자가 다음 EXE 실행 시 업데이트 팝업 자동 표시
```

### EXE 자체를 새로 배포해야 하는 경우

- launcher.py, auto_updater.py, auth_checker.py, login_window.py 등 EXE 내장 파일 변경 시
- 의존성(Telethon, tkinter 버전 등) 변경 시
- AES 키 교체가 필요한 경우 (.aes_key 삭제 후 build.bat 재실행)

---

## 9. Google Sheets 계정 관리

**스프레드시트 URL**: `https://docs.google.com/spreadsheets/d/17FeZ6QSDjfVJanOly36jsGPaImZCMzol7bM8HvnUuRA`

| 컬럼 | 설명 | 예시 |
|------|------|------|
| `ID` | 로그인 아이디 (대소문자 무관) | `papa` |
| `PW` | 비밀번호 (대소문자 구분) | `papa` |
| `EXPIRE` | 만료일 (YYYY-MM-DD, 빈칸=무기한) | `2026-12-31` |
| `STATUS` | 상태 (`ACTIVE` or `INACTIVE`) | `ACTIVE` |

| 관리 작업 | 방법 | 즉시 반영? |
|---------|------|----------|
| 계정 추가 | 새 행 삽입 | ✅ |
| 계정 비활성화 | STATUS → `INACTIVE` | ✅ |
| 계정 삭제 | 행 삭제 | ✅ |
| 비밀번호 변경 | PW 컬럼 수정 | ✅ |
| 사용 기간 연장 | EXPIRE 날짜 수정 | ✅ |
| 강제 만료 | EXPIRE 를 과거 날짜로 수정 | ✅ |

> EXE 를 재배포하지 않아도 위 변경사항이 즉시 반영됩니다.

---

## 10. PyInstaller 빌드 핵심 트러블슈팅

### ⚠️ 문제 1: AES 키 없음 오류 (가장 흔한 문제)

**증상**: EXE 실행 시 `"AES 키 없음 - 빌드가 올바르지 않습니다."` 오류

**원인**: `launcher.py` 가 `from auto_updater import` 구문을 유지하면  
PyInstaller 가 원본 `auto_updater.py` (플레이스홀더 `##AES_KEY##` 포함) 를 번들링.  
`inject_token.py` 가 생성한 `_injected_auto_updater.py` 는 `--add-data` 로  
추가되어도 import 되지 않음.

**해결**: `inject_token.py` 가 `_injected_launcher.py` 생성 시  
`from auto_updater import` → `from _injected_auto_updater import` 로 교체.  
→ PyInstaller 가 `_injected_auto_updater.py` (AES 키 포함) 를 번들에 포함.

```python
# inject_token.py 핵심 로직
launcher_text = launcher_text.replace(
    "from auto_updater import",
    "from _injected_auto_updater import",
)
```

### ⚠️ 문제 2: `'출력:' is not recognized` / `-m` 분리 오류

**원인**: `set "PYTHON_EXE=py -3.11"` 후 `%PYTHON_EXE% -m pip` 실행 시  
CMD 가 `"py -3.11"` + `-m pip` 로 분리.

**해결 (v1.4.2+)**: temp 파일 방식으로 절대 경로 획득.
```bat
echo import sys > "%TEMP%\getpy.py"
echo print(sys.executable) >> "%TEMP%\getpy.py"
py -3.11 "%TEMP%\getpy.py" > "%TEMP%\pypath.txt"
set /p PYTHON_EXE=<"%TEMP%\pypath.txt"
"%PYTHON_EXE%" -m pip install ...   # 절대 경로 → 정상 동작
```

### ⚠️ 문제 3: PermissionError - 실행 중인 EXE 삭제 불가

**원인**: 이전 빌드의 `telegram_parser.exe` 가 실행 중이면 `dist` 폴더 삭제 불가.

**해결 (v1.4.4+)**:
```bat
taskkill /f /im telegram_parser.exe >nul 2>&1
timeout /t 2 /nobreak >nul
rmdir /s /q dist
```

### ⚠️ 문제 4: Python 버전별 호환성

| 버전 | 안정성 | 권장도 |
|------|--------|--------|
| 3.11 | ✅ 최적 | ⭐⭐⭐ 최우선 권장 |
| 3.12 | ✅ 안정 | ⭐⭐ |
| 3.10 | ✅ 안정 | ⭐⭐ |
| 3.13 | ⚠️ 일부 라이브러리 미지원 | ⭐ |
| 3.14 | ⚠️ tkinter 패키징 이슈 | 사용 자제 |

Python 3.11 다운로드: https://www.python.org/downloads/release/python-3119/

### ⚠️ 문제 5: tkinter 패키징 실패 (Python 3.14)

**해결**: 개별 import 사용.
```python
# ❌ 잘못됨
from tkinter import ttk, messagebox

# ✅ 올바름
import tkinter.ttk as ttk
import tkinter.messagebox as messagebox
```

### ⚠️ 문제 6: `.spec` 파일 캐시 오류

**증상**: 이전 빌드 설정(아이콘 경로 등)이 재사용되어 오류 발생.
```bat
del /f /q *.spec        # 반드시 삭제
python -m PyInstaller --clean ...   # --clean 플래그도 함께
```

---

## 11. auto_updater.py 개선 사항 (v1.5.0)

| 기능 | v1.4.x | v1.5.0 |
|------|--------|--------|
| 재시도 | 없음 | 3회, 지수 백오프 (1s → 2s) |
| SHA-256 검증 | 없음 | `enc_sha256` 필드 기반 검증 |
| 타임아웃 | 단일 10초 | 연결 5초 / 읽기 30초 |
| 오류 메시지 | 간단 | HTTP 코드 포함 상세 메시지 |
| 강제 업데이트 | 없음 | `force_update` 필드 지원 |
| URL 생성 | `_raw_url()` 단일 함수 | `_api_url()` 파일별 분리 |

---

## 12. 다른 프로그램에 적용하는 방법

### 필수 체크리스트

- [ ] EXE 이름 결정 (`myapp.exe`)
- [ ] 메인 스크립트 이름 (`myapp.py`)
- [ ] GitHub 레포 / 브랜치 준비
- [ ] `myapp.py` 에 `main()` 함수 존재 (모듈 레벨, `if __name__` 바깥)
- [ ] 사용 라이브러리 확인 (tkinter, PyQt, etc.)
- [ ] Google Sheets 스프레드시트 ID 확보

### Step 1. auto_updater.py 상수 수정

```python
GITHUB_OWNER  = "본인깃헙아이디"   # ← 수정
GITHUB_REPO   = "저장소이름"        # ← 수정
GITHUB_BRANCH = "브랜치이름"        # ← 수정
```

### Step 2. auth_checker.py 시트 ID 수정

```python
SHEET_ID = "본인_구글시트_ID"   # ← URL 에서 추출
GID      = "0"                  # ← 시트 탭 GID (URL 에서 확인)
```

### Step 3. launcher.py 버전 수정

```python
LAUNCHER_VERSION = "1.0.0"    # ← 버전 초기화
APP_TITLE        = "내 앱 이름"  # ← 앱 이름
```

### Step 4. 메인 앱에 main() 함수 추가

```python
# myapp.py 맨 아래
def main():
    app = MyApp()
    app.mainloop()

if __name__ == "__main__":
    main()
```

> `if __name__ == "__main__":` 안에만 있으면 안 됨.  
> `launcher.py` 가 메모리 실행 후 `mod.main()` 을 호출하므로  
> **반드시 모듈 레벨 함수로 분리**해야 함.

### Step 5. version.json 작성

```json
{
  "version": "1.0.0",
  "release_date": "2026-01-01",
  "update_note": "최초 릴리즈",
  "main_script": "myapp.enc",
  "encrypted": true,
  "force_update": false,
  "enc_sha256": ""
}
```

### Step 6. build.bat EXE 이름 수정

```bat
--name "myapp"            ← EXE 이름 변경
"%SCRIPT_DIR%\_injected_launcher.py"   ← 그대로 유지
```

### Step 7. GitHub 브랜치 생성 및 push

```bash
git checkout -b my-branch
git add .
git commit -m "Initial commit"
git push origin my-branch
```

### Step 8. build.bat 실행

```
build.bat
→ .pat 파일에 PAT 토큰 저장 후 실행
→ dist/myapp.exe 생성
→ 이 파일만 사용자에게 전달
```

---

## 13. 자주 발생하는 오류 & 해결법

| 오류 메시지 | 원인 | 해결 |
|-----------|------|------|
| `AES 키 없음` | `##AES_KEY##` 플레이스홀더 미교체 | build.bat 으로 재빌드 |
| `telegram_parser.enc 를 찾을 수 없습니다` | .enc 파일 누락 | build.bat 재실행 |
| `pycryptodome 없음` | 패키지 미설치 | `pip install pycryptodome` |
| `'출력:' is not recognized` | build.bat 인코딩 오류 | v1.4.1+ 에서 해결됨 |
| `Access is denied` (dist 삭제) | EXE 실행 중 | v1.4.4+ 에서 taskkill 추가 |
| `EXE 실행해도 아무 반응 없음` | `--noconsole` 로 오류 숨김 | `error.log` 확인 |
| `SHA-256 무결성 검증 실패` | 파일 손상 또는 불일치 | build.bat 재빌드 후 재배포 |
| 버전 항상 `0.0.0` | `local_version.json` 없음 | 업데이트 1회 실행 시 자동 생성 |
| 로그인 항상 실패 | Google Sheets 접근 불가 | 시트를 "링크 있는 사용자" 로 공유 설정 |

---

## 14. 보안 주의사항

| 항목 | 권장 사항 |
|------|---------|
| `.aes_key` | 절대 GitHub 커밋 금지. 분실 시 build.bat 재실행 (새 키 생성). 기존 사용자는 EXE 재배포 필요. |
| `.pat` | 절대 GitHub 커밋 금지. PAT 만료 시 GitHub → Settings → PAT 에서 갱신 후 재빌드. |
| `_injected_*.py` | 빌드 산출물. build.bat 이 자동 삭제. `.gitignore` 에 추가. |
| PAT 권한 | `repo` 스코프만 부여. 불필요한 권한 부여 금지. |
| Google Sheets | 시트를 공개 공유 (링크 있는 사용자 읽기 가능) 으로 설정. 완전 비공개 시 CSV export 불가. |
| AES 키 교체 | `.aes_key` 삭제 → build.bat 재실행 → 새 `.enc` 생성 → 전체 사용자 EXE 재배포. |

---

## 15. 한계 및 개선 포인트

| 한계 | 설명 | 개선 방법 |
|------|------|----------|
| 업데이트 = 다음 실행 반영 | 현재 실행 중 즉시 반영 불가 | 자동 재시작 기능 추가 가능 |
| SHA-256 서명 없음 | 업로드자 신원 검증 불가 | GitHub Releases + 서명 추가 |
| 단일 .enc 파일만 업데이트 | 추가 리소스 파일 업데이트 불가 | version.json 에 파일 목록 정의 |
| Google Sheets 의존 | Sheets 서버 장애 시 로그인 불가 | 오프라인 캐시 + 만료 기간 로컬 저장 |
| PAT 토큰 수명 | GitHub PAT 만료 시 업데이트 불가 | PAT 자동 갱신 또는 Fine-grained PAT 사용 |
| 역공학 가능성 | AES 키가 EXE 메모리에 존재 | TPM / 하드웨어 키 저장소 사용 (고급) |
