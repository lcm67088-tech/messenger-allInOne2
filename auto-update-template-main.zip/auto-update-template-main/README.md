# 🔄 Python EXE 자동업데이트 + 보안 템플릿

> **버전**: v1.5.0 | **기반 프로젝트**: lcm67088-tech/program222 (telegram-parser)

어떤 Python GUI 앱에도 붙일 수 있는 **로그인 + 자동업데이트 + AES-256 보안** 시스템 템플릿입니다.

---

## 📁 폴더 구조

```
auto-update-template/
│
├── core/                       ← EXE 에 내장되는 런타임 파일
│   ├── auto_updater.py         ← GitHub API 버전체크 / .enc 다운로드
│   ├── auth_checker.py         ← Google Sheets 인증 로직
│   ├── login_window.py         ← 로그인 GUI (Tkinter)
│   └── launcher.py             ← EXE 진입점 (로그인→스플래시→업데이트→실행)
│
├── build/                      ← 개발자 빌드 도구 (EXE 에 포함 안 됨)
│   ├── build.bat               ← PyInstaller 원클릭 빌드 스크립트
│   ├── inject_token.py         ← 빌드 전 PAT/AES 키 자동 주입
│   ├── make_icon.py            ← icon.ico 자동 생성 (Pillow)
│   └── .gitignore              ← 보안 파일 제외 설정
│
├── docs/
│   └── AUTO_UPDATE_SYSTEM.md   ← 전체 시스템 설계 문서
│
├── myapp_template.py           ← 메인 앱 템플릿 (여기서 시작!)
├── version.json                ← 버전 정보 (GitHub 에 올라가는 파일)
└── README.md                   ← 이 파일
```

---

## ⚡ 5분 빠른 시작

### Step 1. 파일을 새 프로젝트 폴더에 배치

```
새프로젝트/
├── core/           ← 그대로 복사
├── build/          ← 그대로 복사
├── myapp.py        ← myapp_template.py 를 복사 후 이름 변경 + 코드 작성
└── version.json    ← 그대로 복사
```

### Step 2. 총 8줄 수정

**`core/auto_updater.py`** (3줄)
```python
GITHUB_OWNER  = "YOUR_GITHUB_USERNAME"   # ← 내 GitHub 아이디
GITHUB_REPO   = "YOUR_REPO_NAME"         # ← 레포 이름
GITHUB_BRANCH = "YOUR_BRANCH_NAME"       # ← 브랜치 이름
```

**`core/auth_checker.py`** (1줄)
```python
SHEET_ID = "YOUR_GOOGLE_SHEET_ID"   # ← 구글 시트 URL 에서 복사
```
> 구글 시트 URL: `https://docs.google.com/spreadsheets/d/`**여기가 SHEET_ID**`/edit`

**`core/launcher.py`** (2줄)
```python
LAUNCHER_VERSION = "1.0.0"          # ← 버전 초기화
APP_TITLE        = "내 앱 이름"      # ← 앱 이름
```

**`build/build.bat`** (2줄)
```bat
Output: dist\YOUR_APP_NAME.exe       ← 앱 이름
--name "YOUR_APP_NAME"               ← 앱 이름
```

### Step 3. 메인 앱 작성

`myapp_template.py` 를 복사해서 실제 앱 코드를 작성하세요.  
**⚠ `main()` 함수는 반드시 모듈 레벨에 있어야 합니다.**

```python
def main():           # ← if __name__ 바깥에 있어야 함!
    app = MyApp()
    app.mainloop()

if __name__ == "__main__":
    main()
```

### Step 4. Google Sheets 준비

스프레드시트를 만들고 아래 컬럼을 추가하세요:

| ID | PW | EXPIRE | STATUS |
|----|----|--------|--------|
| user1 | pass1 | 2026-12-31 | ACTIVE |
| user2 | pass2 | 2026-06-30 | ACTIVE |

> 시트를 **"링크 있는 사용자 — 뷰어"** 로 공유 설정 필수!

### Step 5. GitHub 레포 & 브랜치 생성 후 push

```bash
git init
git checkout -b YOUR_BRANCH_NAME
git add .
git commit -m "Initial commit"
git push origin YOUR_BRANCH_NAME
```

### Step 6. .pat 파일 생성

프로젝트 루트에 `.pat` 파일 생성 후 GitHub PAT 토큰 붙여넣기:
```
github_pat_11XXXXXX...
```

### Step 7. 빌드!

```bat
build\build.bat
```

→ `dist\YOUR_APP_NAME.exe` 생성 완료 🎉

---

## 🔒 4단계 보안 레이어

| 레이어 | 구성 | 효과 |
|--------|------|------|
| **[1] 로그인** | Google Sheets 실시간 인증 | 허가된 사용자만 접근, EXE 재배포 없이 계정 관리 |
| **[2] Private 레포** | PAT XOR+Base64 난독화 | 소스코드 GitHub 비공개, 토큰 역추적 어려움 |
| **[3] AES-256** | 소스 → .enc 암호화 | 디스크에 평문 소스코드 없음 |
| **[4] 메모리 실행** | exec() 직접 실행 | 복호화된 코드가 파일로 저장되지 않음 |

---

## 📤 업데이트 배포 방법 (EXE 재배포 불필요)

```bash
# 1. myapp.py 수정
# 2. version.json 버전 올리기
# 3. build.bat 실행 (새 .enc + SHA-256 자동 생성)
# 4. 커밋 & 푸시
git add myapp.enc version.json
git commit -m "release(1.0.1): 버그 수정"
git push origin YOUR_BRANCH_NAME
# → 사용자가 다음 실행 시 자동 업데이트 팝업!
```

---

## ❗ 절대 GitHub 에 올리면 안 되는 파일

| 파일 | 이유 |
|------|------|
| `.pat` | GitHub PAT 토큰 (노출 시 레포 전체 접근 가능) |
| `.aes_key` | AES 암호화 키 (노출 시 .enc 복호화 가능) |
| `_injected_*.py` | 토큰/키가 삽입된 빌드 중간 파일 |

> `.gitignore` 에 이미 등록되어 있습니다.

---

## 🛠 자주 발생하는 오류

| 오류 | 원인 | 해결 |
|------|------|------|
| `AES 키 없음` | build.bat 으로 빌드 안 함 | `build.bat` 실행 |
| `EXE 아무 반응 없음` | 내부 오류가 콘솔에 숨겨짐 | `error.log` 확인 |
| `로그인 항상 실패` | 구글 시트 비공개 상태 | 시트 공유 설정 확인 |
| `pycryptodome 오류` | 패키지 미설치 | `pip install pycryptodome` |
| `PermissionError dist 삭제` | EXE 실행 중 | EXE 닫고 build.bat 재실행 |

---

## 📚 상세 문서

`docs/AUTO_UPDATE_SYSTEM.md` 를 참고하세요.  
전체 아키텍처, 빌드 흐름, 트러블슈팅 15섹션 포함.

---

## 📋 체크리스트

```
□ auto_updater.py  — GITHUB_OWNER / REPO / BRANCH 수정
□ auth_checker.py  — SHEET_ID 수정
□ launcher.py      — APP_TITLE / LAUNCHER_VERSION 수정
□ build.bat        — --name "앱이름" 수정
□ myapp.py         — main() 함수 모듈 레벨에 작성
□ version.json     — v1.0.0, 앱 이름 확인
□ Google Sheets    — 컬럼(ID/PW/EXPIRE/STATUS) + 공유 설정
□ GitHub           — 레포 Private 설정 + 브랜치 push
□ .pat 파일        — PAT 토큰 저장
□ build.bat 실행   — dist/앱이름.exe 생성 확인
```
